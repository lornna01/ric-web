import { BaseModel, column } from '@adonisjs/lucid/orm'

export default class Departamento extends BaseModel {
  static table = 'departamentos'
  
  @column({ isPrimary: true })
  declare id: number

  @column()
  declare nombre: string


}