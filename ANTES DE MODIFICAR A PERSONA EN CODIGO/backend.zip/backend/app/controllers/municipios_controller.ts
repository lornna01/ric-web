import Municipio from '#models/municipio'
import type { HttpContext } from '@adonisjs/core/http'

export default class MunicipiosController {
  /**
   * Display a list of resource
   */
  async index({ response,request }: HttpContext) {
    try {
      
      const info = await Municipio.query()
      .where('departamento_id', request.input("departamento_id"))
      .orderBy('nombre', 'asc')
      .preload('departamento') // Cargar la relación 'rol'
      .exec()
        

      return response.ok(info)
    } catch (error) {
      console.error(error)
      return response.badRequest({ message: 'Error al obtener.' })
    }
  }

  /**
   * Handle form submission for the create action
   */
  async store({ request,response }: HttpContext) {
    const data = request.all();
    const existe = await Municipio.query().where('nombre', data.nombre).where('departamento_id', data.departamento_id).first();
    if (!existe) {
      const user = await Municipio.create(data);
      return response.created(user);
    } else {
      return response.badRequest({ message: "Ya existe" });
    }
  }

  /**
   * Show individual record
   */
  async show({ params, response }: HttpContext) {
    const existe = await Municipio.findBy(params.id);
    if(existe)
      return response.json(existe);
    return response.notFound();
  }

  /**
   * Handle form submission for the edit action
   */
  async update({ params, request,response }: HttpContext) {
    try{
    const model = await Municipio.findOrFail(params.id);
      if (model) {
      const data = request.all();
   
        model.nombre = data.nombre
        model.departamento_id = data.departamento_id
        
        model.save()
        return response.json(model);
    } else {
      return response.badRequest({ message: "No existe"});
    }
  } catch (error) {
    console.error(error)
    return response.badRequest({ message: 'Error al obtener.' })
  }
  }

  /**
   * Delete record
   */
  async destroy({ params,response }: HttpContext) {
    const expe = await Municipio.findOrFail(params.id);
    if (expe) {
      expe.delete();
      return response.json({message:"eliminado!"});
    } else {
      return response.badRequest({ message: "No existe"});
    }
  }
}