import Departamento from '#models/departamento';
import type { HttpContext } from '@adonisjs/core/http'

export default class DepartamentosController {
  /**
   * Display a list of resource
   */
  async index({ response }: HttpContext) {
    const data = await Departamento.query()
      .orderBy('nombre', 'asc')
      .exec()
    return response.json(data)
  }

  /**
   * Handle form submission for the create action
   */
  async store({ request,response }: HttpContext) {
    const data = request.only(['nombre','descripcion']);
    const existe = await Departamento.query().where('nombre', data.nombre).first();
    if (!existe) {
      const user = await Departamento.create(data);
      return response.created(user);
    } else {
      return response.badRequest({ message: "Ya existe:" + data.nombre });
    }
  }

  /**
   * Show individual record
   */
  async show({ params,response }: HttpContext) {
    const data = await Departamento.findOrFail(params.id);
    return response.json(data);
  }

  /**
   * Handle form submission for the edit action
   */
  async update({ params, request,response }: HttpContext) {
    const model = await Departamento.findOrFail(params.id);
    if (model) {
      const data = request.only(['nombre']);
      model.nombre = data.nombre
     
      model.save()
      return response.json(model);
    } else {
      return response.badRequest({ message: "No existe"});
    }
  }

  /**
   * Delete record
   */
  async destroy({ params,response }: HttpContext) {
    const model = await Departamento.findOrFail(params.id);
    if (model) {
      model.delete();
      return response.json({message:"eliminado!"});
    } else {
      return response.badRequest({ message: "No existe"});
    }
  }
}