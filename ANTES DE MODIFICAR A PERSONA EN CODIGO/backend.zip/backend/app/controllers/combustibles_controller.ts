import Combustible from '#models/combustible'
import Vehiculo from '#models/vehiculo';
import type { HttpContext } from '@adonisjs/core/http'

export default class CombustiblesController {
  /**
   * Display a list of resource
   */
  async index({ response,request }: HttpContext) {
    try {
      
      const info = await Combustible.query().where('placa', request.input('placa')).orderBy('id','desc').exec();
      return response.ok(info)
    } catch (error) {
      console.error(error)
      return response.badRequest({ message: 'Error al obtener.' })
    }
  }

  /**
   * Handle form submission for the create action
   */
  async store({ request,response }: HttpContext) {
    const data = request.all();
    const existe = await Vehiculo.query().where('placa', data.placa).first();
    if (existe) {
      const model = await Combustible.create(data);
      return response.created(model);
    } else {
      return response.notFound({ message: "No existe el vehículo" });
    }
  }

  /**
   * Show individual record
   */
  async show({ params, response }: HttpContext) {
    const existe = await Combustible.findBy(params.id);
    if(existe)
      return response.json(existe);
    return response.notFound();
  }

  /**
   * Handle form submission for the edit action
   */
  async update({ params, request,response }: HttpContext) {
    try {
      const data = request.all();

        const model = await Combustible.query().where('id', params.id).first();
        model!!.kilometraje_final = data.kilometraje_final
        
        model!!.usuario_id = data.usuario_id
        
        model!!.save()
        return response.json(model);
  
  } catch (error) {
    console.error(error)
    return response.badRequest({ message: 'Error al obtener.' })
  }
  }

  /**
   * Delete record
   */
  async destroy({ params,response }: HttpContext) {
    const expe = await Combustible.findOrFail(params.id);
    if (expe) {
      expe.delete();
      return response.json({message:"eliminado!"});
    } else {
      return response.badRequest({ message: "No existe"});
    }
  }
}