import User from '#models/user'
import type { HttpContext } from '@adonisjs/core/http'

export default class UsersController {
  /**
   * Display a list of resource
   */
  async index({ response }: HttpContext) {
    try {
      const users = await User.query()
        .preload('rol') // Cargar la relación 'rol'
        .exec()
        

      return response.ok(users)
    } catch (error) {
      console.error(error)
      return response.badRequest({ message: 'Error al obtener usuarios con roles.' })
    }
  }

  /**
   * Handle form submission for the create action
   */
  async store({ request,response }: HttpContext) {
    const data = request.all();
    const existe = await User.query().where('email', data.email).first();
    if (!existe) {
      const user = await User.create(data);
      return response.created(user);
    } else {
      return response.badRequest({ message: "Ya existe un usuario con correo:" + data.email });
    }
  }

  /**
   * Show individual record
   */
  async show({ params,response }: HttpContext) {
    const user = await User.findOrFail(params.id);
    return response.json(user);
  }

  /**
   * Handle form submission for the edit action
   */
  async update({ params, request,response }: HttpContext) {
    const user = await User.findOrFail(params.id);
    if (user) {
      const data = request.only(['nombre', 'email', 'password','estado', 'rol_id']);
      user.nombre = data.nombre
      user.email = data.email
      user.password = data.password
      user.estado = data.estado
      user.rol_id = data.rol_id
      user.save()
      return response.json(user);
    } else {
      return response.badRequest({ message: "No existe un usuario"});
    }
  }

  /**
   * Delete record
   */
  async destroy({ params,response }: HttpContext) {
    const user = await User.findOrFail(params.id);
    if (user) {
      user.delete();
      return response.json({message:"Usuario eliminado!"});
    } else {
      return response.badRequest({ message: "No existe un usuario"});
    }
  }
}