import Expediente from '#models/expediente'
import type { HttpContext } from '@adonisjs/core/http'

export default class ExpedientesController {
  /**
   * Display a list of resource
   */
  async index({ response }: HttpContext) {
    try {
      const info = await Expediente.query()
      .orderBy('id', 'desc')
      .preload('estado')
      .preload('municipio')
      .preload('departamento')
      .preload('usuario', (builder) => {
        builder.preload('rol')
      }) // Cargar la relación 'rol'
        .exec()
        

      return response.ok(info)
    } catch (error) {
      console.error(error)
      return response.badRequest({ message: 'Error al obtener.' })
    }
  }

  /**
   * Handle form submission for the create action
   */
  async store({ request,response }: HttpContext) {
    const data = request.all();
    try {
      const existe = await Expediente.query()
        .where('predio', data.predio)
        .where('departamento_id', data.departamento_id)
        .where('municipio_id', data.municipio_id)
        .where('poligono', data.poligono)
        .first();
        if (existe) {
          return response.badRequest({ message: "Ya existe" });
        }
      const user = await Expediente.create(data);
      return response.created(user);
    } catch (err) {
      console.error(err)
      return response.badRequest({ message: "Verifica los datos",data });
    }
  }

  /**
   * Show individual record
   */
  async show({ params, response }: HttpContext) {
    const existe = await Expediente.findOrFail(params.id);
      return response.json(existe);
  }

  /**
   * Handle form submission for the edit action
   */
  async update({ params, request,response }: HttpContext) {
    try{
    const model = await Expediente.findOrFail(params.id);
      if (model) {
      const data = request.all();

        model.departamento_id = data.departamento_id
        model.municipio_id = data.municipio_id
        model.poligono = data.poligono
        model.predio = data.predio
        model.leitz = data.leitz
        model.titular = data.titular
        model.estanteria = data.estanteria
        model.nivel = data.nivel
        model.hojas = data.hojas
        model.comentarios = data.comentarios
        model.expediente_estado_id = data.expediente_estado_id
        model.archivo = data.archivo
        model.save()
        return response.json(model);
    } else {
      return response.badRequest({ message: "No existe"});
    }
  } catch (error) {
    console.error(error)
    return response.badRequest({ message: 'Error al obtener.' })
  }
  }

  /**
   * Delete record
   */
  async destroy({ params,response }: HttpContext) {
    const expe = await Expediente.findOrFail(params.id);
    if (expe) {
      expe.delete();
      return response.json({message:"Exp eliminado!"});
    } else {
      return response.badRequest({ message: "No existe"});
    }
  }
}