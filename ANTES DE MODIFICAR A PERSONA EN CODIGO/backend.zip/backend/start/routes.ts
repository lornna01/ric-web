/*
|--------------------------------------------------------------------------
| Routes file
|--------------------------------------------------------------------------
|
| The routes file is used for defining the HTTP routes.
|
*/

import UsersController from '#controllers/users_controller';
import router from '@adonisjs/core/services/router'
import { middleware } from './kernel.js';
import AuthController from '#controllers/auth_controller';
import RolController from '#controllers/rol_controller';
import EstadoExpedientesController from '#controllers/estado_expedientes_controller';
import ExpedientesController from '#controllers/expedientes_controller';
import DepartamentosController from '#controllers/departamentos_controller';
import MunicipiosController from '#controllers/municipios_controller';
import MovimientoExpedientesController from '#controllers/movimiento_expedientes_controller';
import VehiculosController from '#controllers/vehiculos_controller';
import ElasticEmail  from '@elasticemail/elasticemail-client';
import CombustiblesController from '#controllers/combustibles_controller';
import BoletasController from '#controllers/boletas_controller';




router.get('/', async () => {
  
  return {
    hello: 'world',
  }
})


router.group(() => {

  router.group(() => {
    router.resource('usuarios', UsersController);
    router.resource('roles', RolController);
    router.resource('estadoExpedientes', EstadoExpedientesController);
    router.resource('expedientes', ExpedientesController);
    router.resource('departamentos', DepartamentosController);
    router.resource('municipios', MunicipiosController);
    router.resource('movimientos', MovimientoExpedientesController);
    router.resource('vehiculos', VehiculosController);
    router.resource('combustibles', CombustiblesController);
    router.resource('boletas', BoletasController);
    router.get('vehiculosByPlaca/:placa', [VehiculosController,'showByPlaca']);
    router.get('boletaBySerie/:serie', [BoletasController,'showBySerie']);
    router.get('me', [AuthController,'me']);
    router.get('logout', [AuthController,'logout']);
  }).use(
    middleware.auth({
      guards:['api'],
    })
  );

  router.group(() => {
    router.post('login', [AuthController,'login']);
    router.post('register', [AuthController,'register']);
  }).prefix('/auth');
  

}).prefix('/api/v1');

