import React, { useState } from 'react'
import { useAuth } from '../providers/AuthContextProvider';
import BuscarExpediente from '../pages/BuscarExpediente';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

  
const NavBar = () => {
    const { logout } = useAuth();
  const { user } = useAuth();
  
  const [buscarccc, setBuscarCcc] = useState();
  const [enviar, setEnviar] = useState(false);
  const navigate = useNavigate();

  return (
      <>
      {/* Navbar */}
      <nav
              className="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
              id="layout-navbar"
            >
              <div className="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                <a className="nav-item nav-link px-0 me-xl-4" href="#">
                  <i className="mdi mdi-menu mdi-24px" />
                </a>
              </div>
              <div
                className="navbar-nav-right d-flex align-items-center"
                id="navbar-collapse"
              >
                {/* Search */}
                <div className="navbar-nav align-items-center">
                  <div className="nav-item d-flex align-items-center">
                  <i className="bx bx-box text-success me-1" />{" "}
                    {user.user.rol.nombre}
                  </div>
                </div>
                {/* /Search */}
                <ul className="navbar-nav flex-row align-items-center ms-auto">
                  {/* Place this tag where you want the button to render. */}
                  <li className="nav-item lh-1 me-3">
                    <span />
                  </li>
                  {/* User */}
                  <li className="nav-item navbar-dropdown dropdown-user dropdown">
                    <a
                      className="nav-link dropdown-toggle hide-arrow p-0"
                      href="#"
                      data-bs-toggle="dropdown"
                    >
                      <div className="avatar avatar-online">
                        <img
                          src="/img/avatars/1.png"
                          alt
                          className="w-px-40 h-auto rounded-circle"
                        />
                      </div>
                    </a>
                    <ul className="dropdown-menu dropdown-menu-end mt-3 py-2">
                      <li>
                        <a
                          className="dropdown-item pb-2 mb-1 waves-effect"
                          href="#"
                        >
                          <div className="d-flex align-items-center">
                            <div className="flex-shrink-0 me-2 pe-1">
                              <div className="avatar avatar-online">
                                <img
                                  src="/img/avatars/1.png"
                                  alt
                                  className="w-px-40 h-auto rounded-circle"
                                />
                              </div>
                            </div>
                            <div className="flex-grow-1">
                              <h6 className="mb-0">{user.nombre}</h6>
                              <small className="text-muted">
                                {user.user.rol.nombre}
                              </small>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li>
                        <div className="dropdown-divider my-1" />
                      </li>
                      
                      <li>
                        <a className="dropdown-item waves-effect" href="#">
                          <i className="mdi mdi-cog-outline me-1 mdi-20px" />
                          <span className="align-middle">Cambiar Contraseña</span>
                        </a>
                      </li>
                      
                      <li>
                        <div className="dropdown-divider my-1" />
                      </li>
                      <li>
                        <a
                          className="dropdown-item waves-effect"
                          href="#"
                          onClick={logout}
                        >
                          <i className="mdi mdi-power me-1 mdi-20px" />
                          <span className="align-middle">Cerrar sesión</span>
                        </a>
                      </li>
                    </ul>
                  </li>
                  {/*/ User */}
                </ul>
              </div>
      </nav>
      
      
      </>
  )
}

export default NavBar