import React from 'react'
import { Link,useLocation } from "react-router-dom";

const MenuLateral = () => {
  const location = useLocation();
  return (
      <>
          {/* Menu */}
          <aside
            id="layout-menu"
            className="layout-menu menu-vertical menu bg-menu-theme"
            data-bg-class="bg-menu-theme"
          >
            <div className="app-brand demo">
              <a href="index.html" className="app-brand-link">
                <span className="app-brand-logo demo me-1">
                  <span style={{ color: "var(--bs-primary)" }}>
                    <img src="/img/ric.jpeg" alt="" width={'150'} />
                  </span>
                </span>
              </a>
              <a
                href="#"
                className="layout-menu-toggle menu-link text-large ms-auto"
              >
                <i className="mdi menu-toggle-icon d-xl-block align-middle mdi-20px" />
              </a>
            </div>
            <div className="menu-inner-shadow" />
            <ul className="menu-inner py-1 ps ps--active-y">
              {/* Dashboards */}
              <li className={`menu-item ${location.pathname === '/home' ? 'active' : ''}`}>
                <Link to="/home" className="menu-link waves-effect">
                  <i className="menu-icon tf-icons mdi mdi-home-outline" />
                  <div data-i18n="Dashboards">Inicio</div>
                </Link>
              </li>
              
              
              <li className={`menu-header fw-medium mt-4`}>
                <span className="menu-header-text">ARCHIVO</span>
              </li>
              {/* Apps */}
              <li className={`menu-item ${location.pathname === '/expedientes/nuevo' ? 'active' : ''}`}>
                <Link to="/expedientes/nuevo" className="menu-link waves-effect">
                  <i className="menu-icon tf-icons mdi mdi-file-outline" />
                  <div data-i18n="Dashboards">Nuevo expediente</div>
                </Link>
          </li>
          <li className={`menu-item ${location.pathname === '/vehiculos/nuevo' ? 'active' : ''}`}>
                <Link to="/vehiculos/nuevo" className="menu-link waves-effect">
                  <i className="menu-icon tf-icons mdi mdi-car-outline" />
                  <div data-i18n="Dashboards">Vehículos</div>
                </Link>
          </li>
          <li className={`menu-item ${location.pathname === '/combustible/nuevo' ? 'active' : ''}`}>
                <Link to="/combustible/nuevo" className="menu-link waves-effect">
                  <i className="menu-icon tf-icons mdi mdi-fire" />
                  <div data-i18n="Dashboards">Combustible</div>
                </Link>
          </li>
          <li className={`menu-item ${location.pathname === '/boleta/nueva' ? 'active' : ''}`}>
                <Link to="/boleta/nueva" className="menu-link waves-effect">
                  <i className="menu-icon tf-icons mdi mdi-ticket" />
                  <div data-i18n="Dashboards">Boleta</div>
                </Link>
              </li>
              
              
              
            </ul>
          </aside>
          {/* / Menu */}
      </>
  )
}

export default MenuLateral