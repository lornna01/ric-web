import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider, useAuth } from './providers/AuthContextProvider';
import PrivateRoute from './routes/privateRoute';
import Home from './pages/Home';
import Login from './pages/Login';
import Profile from './pages/Profile';
import NoPage from './pages/NoPage';
import EditarUsuario from './pages/EditarUsuario';
import NuevoExpediente from './pages/NuevoExpediente';
import BuscarExpediente from './pages/BuscarExpediente';
import NuevoVehiculo from './pages/NuevoVehiculo';
import NuevoCombustible from './pages/NuevoCombustible';
import NuevaBoleta from './pages/NuevaBoleta';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/home" element={<PrivateRoute><Home /></PrivateRoute>} />
          <Route path="/profile" element={<PrivateRoute><Profile /></PrivateRoute>} />
          <Route path="/editarUsuario" element={<PrivateRoute><EditarUsuario /></PrivateRoute>} />

          
          <Route path="/expedientes/nuevo" element={<PrivateRoute><NuevoExpediente /></PrivateRoute>} />
          <Route path="/expedientes/:buscarId" element={<PrivateRoute><BuscarExpediente /></PrivateRoute>} />

          <Route path="/vehiculos/nuevo" element={<PrivateRoute><NuevoVehiculo /></PrivateRoute>} />
          <Route path="/combustible/nuevo" element={<PrivateRoute><NuevoCombustible /></PrivateRoute>} />
          <Route path="/boleta/nueva" element={<PrivateRoute><NuevaBoleta /></PrivateRoute>} />
          <Route path="/" element={<Login />} />
          <Route path="*" element={<NoPage />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
