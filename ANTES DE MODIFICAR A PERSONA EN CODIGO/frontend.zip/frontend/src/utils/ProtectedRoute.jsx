import React from 'react'

const ProtectedRoute = () => {
  return (
    <div>ProtectedRoute</div>
  )
}

export default ProtectedRoute